import React, { useState, useEffect } from 'react';
import { SearchBar } from '../components/SearchBar';
import { IndexStatus } from '../components/IndexStatus';
import { SearchResults } from '../components/SearchResults';
import { EmptyState } from '../components/EmptyState';
import { FolderSelector } from '../components/FolderSelector';
import { ContextModal } from '../components/ContextModal';
import { SearchResponse, IndexStatusResponse, SearchResultItem, SearchHistoryItem } from '../types';
import { api } from '../services/api';
import { Clock, Trash2 } from 'lucide-react';

export const Home: React.FC = () => {
  const [query, setQuery] = useState('');
  const [searchResults, setSearchResults] = useState<SearchResponse | null>(null);
  const [indexStatus, setIndexStatus] = useState<IndexStatusResponse | null>(null);
  const [searchHistory, setSearchHistory] = useState<SearchHistoryItem[]>([]);
  const [selectedContext, setSelectedContext] = useState<SearchResultItem | null>(null);
  const [isFolderManagerOpen, setIsFolderManagerOpen] = useState(false);
  const [isSearching, setIsSearching] = useState(false);
  const [isLoadingStatus, setIsLoadingStatus] = useState(false);

  // Poll index status while indexing is running
  useEffect(() => {
    loadStatus();
    loadHistory();

    const interval = setInterval(() => {
      api.getIndexStatus().then((status) => {
        setIndexStatus(status);
      }).catch(() => {});
    }, 2500);

    return () => clearInterval(interval);
  }, []);

  const loadStatus = async () => {
    try {
      setIsLoadingStatus(true);
      const s = await api.getIndexStatus();
      setIndexStatus(s);
    } catch (err) {
      console.error('Failed loading index status', err);
    } finally {
      setIsLoadingStatus(false);
    }
  };

  const loadHistory = async () => {
    try {
      const h = await api.getSearchHistory();
      setSearchHistory(h);
    } catch (err) {
      console.error('Failed loading history', err);
    }
  };

  const handleSearch = async (searchQuery: string) => {
    if (!searchQuery.trim()) return;
    try {
      setIsSearching(true);
      const res = await api.search(searchQuery.trim());
      setSearchResults(res);
      loadHistory();
    } catch (err) {
      console.error('Search failed', err);
    } finally {
      setIsSearching(false);
    }
  };

  const handleAddFolder = async (path: string) => {
    await api.addFolder(path);
    await loadStatus();
  };

  const handleRemoveFolder = async (folderId: number) => {
    await api.removeFolder(folderId);
    await loadStatus();
  };

  const handleReindex = async () => {
    await api.startIndexing(undefined, true);
    await loadStatus();
  };

  const handleClearHistory = async () => {
    await api.clearSearchHistory();
    setSearchHistory([]);
  };

  const handleUseDemo = async () => {
    try {
      await api.addFolder('data/sample_documents/DSA');
      await loadStatus();
    } catch (err) {
      console.error(err);
    }
  };

  const hasFiles = indexStatus ? indexStatus.total_files > 0 : false;

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      {/* Index Status Bar */}
      <IndexStatus
        status={indexStatus}
        onRefresh={loadStatus}
        onReindex={handleReindex}
        onAddFolderClick={() => setIsFolderManagerOpen(true)}
        isLoading={isLoadingStatus}
      />

      {/* Main Search Input */}
      <SearchBar
        query={query}
        setQuery={setQuery}
        onSearch={handleSearch}
        isLoading={isSearching}
      />

      {/* If no files indexed, display clean empty state */}
      {!hasFiles && !indexStatus?.is_indexing && (
        <EmptyState
          onAddFolder={() => setIsFolderManagerOpen(true)}
          onUseSampleFolder={handleUseDemo}
        />
      )}

      {/* Search Results Display */}
      {searchResults && (
        <div className="mt-8">
          <SearchResults
            response={searchResults}
            onShowContext={(item) => setSelectedContext(item)}
          />
        </div>
      )}

      {/* Recent Searches */}
      {searchHistory.length > 0 && !searchResults && hasFiles && (
        <div className="mt-8 pt-6 border-t border-neutral-200">
          <div className="flex items-center justify-between mb-3 text-xs text-neutral-500">
            <span className="font-semibold text-neutral-800">Recent Searches</span>
            <button
              onClick={handleClearHistory}
              className="flex items-center gap-1 text-neutral-400 hover:text-neutral-700"
              title="Clear search history"
            >
              <Trash2 className="w-3 h-3" />
              Clear
            </button>
          </div>
          <div className="space-y-1.5">
            {searchHistory.slice(0, 5).map((item) => (
              <button
                key={item.id}
                onClick={() => {
                  setQuery(item.query);
                  handleSearch(item.query);
                }}
                className="w-full flex items-center justify-between px-3 py-2 text-xs text-left bg-white hover:bg-neutral-50 border border-neutral-200 rounded transition-colors"
              >
                <div className="flex items-center gap-2 text-neutral-700">
                  <Clock className="w-3.5 h-3.5 text-neutral-400 shrink-0" />
                  <span className="font-mono">{item.query}</span>
                </div>
                <span className="text-[11px] text-neutral-400 font-mono">
                  {item.result_count} {item.result_count === 1 ? 'match' : 'matches'}
                </span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Folder Selector Dialog */}
      <FolderSelector
        folders={indexStatus?.indexed_folders || []}
        onAddFolder={handleAddFolder}
        onRemoveFolder={handleRemoveFolder}
        isOpen={isFolderManagerOpen}
        onClose={() => setIsFolderManagerOpen(false)}
      />

      {/* Context Inspection Modal */}
      <ContextModal
        result={selectedContext}
        onClose={() => setSelectedContext(null)}
      />
    </div>
  );
};
